mv ./json/*.json /mnt/c/Users/jozef/OneDrive/Desktop/uivision/macros/PWP/
