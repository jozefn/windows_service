mv /mnt/c/Users/jozef/Downloads/download_*.csv /home/jozefn/data/
