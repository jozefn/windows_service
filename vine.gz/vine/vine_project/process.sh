cd /home/jozefn/service/macros/vine/vine_project/
./frommv.sh
./vine_parse.pl svine.db 
rm -fr ~/data/*
