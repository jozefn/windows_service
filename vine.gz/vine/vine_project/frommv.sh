mv /mnt/c/Users/jozef/Downloads/*_download_*.csv /home/jozefn/data/
