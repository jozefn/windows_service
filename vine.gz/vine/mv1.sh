mv ./json/$1.json /mnt/c/Users/jozef/OneDrive/Desktop/uivision/macros/PWP/
