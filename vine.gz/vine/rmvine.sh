rm -fr /mnt/c/Users/jozef/OneDrive/Desktop/uivision/macros/PWP/*.json
